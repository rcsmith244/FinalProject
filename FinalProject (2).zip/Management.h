#ifndef MANAGEMENT_H
#define MANAGEMENT_H
#include <vector>
using namespace std;
#include "SupplierInfo.h"
#include "Categories.h"
#include "Orders.h"

class Management
{

	private:
		vector<SupplierInfo*> supInfo;
		vector<Orders*> orders;

	public:
		Management();
		~Management();
		void restock(vector<Categories*> items);
		void printTotalSalesByDate();
		void paySuppliers();
		void printBalanceSheet();
		void loadSupplierInfo();
		void printSupplierInfo();
		void writeToOrdersFile(int buyCount, double itemCost, string supplierName, string supplierAddress, string supplierPhoneNumber, string supplierEmail, string itemName);
		string generateID();
		string generateDate();
		void printSupOrders();
};

#endif