#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <cassert>
#include <random>
#include <stdio.h>      
#include <stdlib.h>     
#include <time.h> 
#include<sstream>
#pragma warning(disable : 4996)
using namespace std;

#include "SupplierInfo.h"
#include "Management.h"
#include "Categories.h"


Management::Management() {

    
}
Management::~Management() {}

void Management::printSupOrders() {

    cout << setw(14) << "Order Number"
        << setw(14) << "Sup Name"
        << setw(14) << "Item Cata"
        << setw(14) << "Item Name"
        << setw(14) << "Date of Sale"
        << setw(14) << "Delivery Date" 
        << setw(14) << "Total Due" << endl;

    int count = 1;
    for (auto& i : orders) {
        cout << count << ". ";
        cout << i->getOrderNumber() <<
            setw(21) << i->getSupName() <<
            setw(14) << i->getItemCata() <<
            setw(14) << i->getItemName() <<
            setw(14) << i->getDateOfSale() <<
            setw(14) << i->getDeliveryDate() <<
            setw(14) << "$" << i->getOrderTotal() << endl;
        count++;
    }
    cout << endl;

}

string Management::generateID() {
   
    srand(time(0));
    int randomInt = 0;

    string const legalChars(
        "0123456789");
    string results;
    while (results.size() != 6) {
        randomInt = rand() % 10 + 1;
        results += legalChars[randomInt];
    }
    return results;
}

string Management::generateDate() {

    stringstream date;
   
    time_t now = time(0);
    tm* ltm = localtime(&now);

    int month = ltm->tm_mon + 1;
    int day = ltm->tm_mday;
    int year = 1900 + ltm->tm_year;
    
    date << month << "/" << day << "/" << year;

    return date.str();
}

void Management::restock(vector<Categories*> items) {

    cout << "Item Name " << setw(14) <<
        " # In Stock " << setw(14) <<
        " Needs reordered? " << endl;
 
    for (auto& i : items) {
        cout << i->getItemName() << setw(14) << i->getItemCount();
        if (i->getReorderItem() == true) {
            cout << setw(14) << "Yes" << endl;
        }
        else {
            cout << endl;
        }

    }
    cout << endl;
    printSupplierInfo();

    cout << endl;
    cout << "Which item do you want to restock?" << endl;
    // TODO: Add option to go back with 0 key
    int menuOption;
    cin >> menuOption;
    menuOption = menuOption - 1; //subtract the 1 here so we don't have to do it each time.
    if (menuOption >= items.size()) {
        cout << "Item not found..." << endl;
    }
    else {
        int buyCount;
        cout << "How many " << items[menuOption]->getMeasurement()
            << " of " << items[menuOption]->getItemName()
            << " would you like to buy?" <<  endl;
        cin >> buyCount;

        cout << "You purchased " << buyCount << " " << items[menuOption]->getItemName() << " @ $" << supInfo[menuOption]->getItemCost() << endl;

        items[menuOption]->setItemCount(buyCount + items[menuOption]->getItemCount());

        orders.emplace_back(new Orders(generateID(), supInfo[menuOption]->getSupplierName(), supInfo[menuOption]->getSupplierAddress(), supInfo[menuOption]->getSupplierEmail(), items[menuOption]->getCatName(), items[menuOption]->getItemName(), generateDate(), generateDate(), supInfo[menuOption]->getItemCost(), buyCount));

    }
}

void Management::printTotalSalesByDate() {

    fstream file;
    string line;
    string currentDate = "";
    double runningTotal = 0;
    
    file.open("SalesFile.txt", ios::in);
    if (!file.is_open()) {
        cout << "File cannot be opened" << endl;
        //assert(false);
    }

    cout << "Date" << setw(14) << "Total Sales";

    while (getline(file, line)) {

        // Splits the string using substrings and find
        string nextDate = line.substr(0, line.find(','));

        if (currentDate.compare("") == 0) {
            currentDate = nextDate;
        } 
        else if (currentDate.compare(nextDate) != 0) {
            cout << currentDate << setw(14) <<" $" << runningTotal << endl;
            runningTotal = 0;
            currentDate = nextDate;
        }

        size_t startLocation = line.find(',') + 1;
        size_t size = line.find(',', startLocation + 1) - startLocation;
        runningTotal+= stod(line.substr(startLocation, size));

        cout << endl;

    }

    cout << currentDate << " $" << runningTotal;

    file.close();

}

void Management::writeToOrdersFile(int buyCount, double itemCost, string supplierName, string supplierAddress, string supplierPhoneNumber, string supplierEmail, string itemName) {

    double orderTotal = buyCount * itemCost;
    time_t now = time(0);
    tm* ltm = localtime(&now);

    fstream file;
    string line;
    file.open("OrdersFile.txt", ios::app);
    if (!file.is_open()) {
        cout << "File cannot be opened" << endl;
        assert(false);
    }

    file << generateDate() << "," << orderTotal << "," << supplierName << "," << supplierAddress << "," << supplierPhoneNumber << "," << supplierEmail << "," << itemName << "," << itemCost << "," << endl;

    file.close();

}

void Management::paySuppliers() {

    printSupOrders();
    int menuOption;
    double amountToPay;
    double balance;

    cout << "Which supplier would you like to make a payment towards? ";
    cin >> menuOption;
    menuOption = menuOption - 1;

    cout << "Enter an amount to pay towards the balance: ";
    cin >> amountToPay;

    balance = orders[menuOption]->getOrderTotal() - amountToPay;
    orders[menuOption]->setOrderTotal(balance);
    
}
void Management::printBalanceSheet() {

    string currentDate = "";
    string nextDate = orders[0]->getDateOfSale();
    double totalDebt = 0;
    string back = "";

    for (auto& i : orders) {
        if (currentDate.compare("") == 0) {
            currentDate = nextDate;
        } 
        else if (currentDate.compare(nextDate) != 0) {
            cout << "Date" << "     Total Debt" << endl;
            cout << currentDate << " $" << totalDebt << endl;
        }
        totalDebt = totalDebt + i->getOrderTotal();
    }

    cout << "Date" << "     Total Debt" << endl;
    cout << currentDate << " " << totalDebt << endl;

    system("pause");

}

void Management::loadSupplierInfo() {

    ifstream file;
    string line;
    file.open("SupplierInfo.txt", ios::in);
    if (!file.is_open()) {
        cout << "File cannot be opened" << endl;
        assert(false);
    }

    while (getline(file, line)) {

        // Splits the string using substrings and find
        int pos = line.find(",");

        string supplierName = line.substr(0, pos);

        size_t startLocation = line.find(',') + 1;
        size_t size = line.find(',', startLocation + 1) - startLocation;
        string address = line.substr(startLocation, size);

        startLocation = line.find(',', startLocation) + 1;
        size = line.find(',', startLocation + 1) - startLocation;
        string phoneNum = line.substr(startLocation, size);

        startLocation = line.find(',', startLocation) + 1;
        size = line.find(',', startLocation + 1) - startLocation;
        string emailAddress = line.substr(startLocation, size);

        startLocation = line.find(',', startLocation) + 1;
        size = line.find(',', startLocation + 1) - startLocation;
        string itemName = line.substr(startLocation, size);

        startLocation = line.find(',', startLocation + 1) + 1;
        size = line.find(',', startLocation + 1) - startLocation;
        double itemCost = stod(line.substr(startLocation, size));
        
        supInfo.emplace_back(new SupplierInfo(supplierName, address, phoneNum, emailAddress, itemName, itemCost));

    }
    file.close();

}

void Management::printSupplierInfo() {

    cout << "   Company Name"
        << setw(14) << " Phone Number "
        << setw(14) << " E-mail Address "
        << setw(14) << " Item Name " 
        << setw(14) << " Item Cost " << endl;

    int count = 1;
    for (auto & i : supInfo) {
        cout << count << ". ";
        cout << i->getSupplierName() <<
            setw(14) << i->getSupplierPhoneNumber() <<
            setw(14) << i->getSupplierEmail() <<
            setw(14) << i->getItemName() <<
            setw(14) << i->getItemCost() << endl;
        count++;
    }
    cout << endl;

}