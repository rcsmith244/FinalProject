#include <iostream>
#include "SalesInterface.h"
using namespace std;

int main() {
	
	SalesInterface::SalesInterface();

	return 0;
}