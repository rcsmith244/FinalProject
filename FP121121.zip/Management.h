#ifndef MANAGEMENT_H
#define MANAGEMENT_H
#include <vector>
using namespace std;
#include "SalesInterface.h"
#include "SupplierInfo.h"
#include "Sales.h"
#include "Categories.h"
#include "Orders.h"
#include "BalanceSheet.h"


class Management
{

	private:
		vector<SupplierInfo> supInfo;
		vector<Orders> orders;
		vector<BalanceSheet> balanceSheet;

	public:
		Management();
		~Management();
		void restock(vector<Categories*> items);
		void printTotalSalesByDate();
		void paySuppliers();
		void printBalanceSheet(vector<Sales> sales);
		void loadSupplierInfo();
		void printSupplierInfo();
		void writeToOrdersFile(int buyCount, double itemCost, string supplierName, string supplierAddress, string supplierPhoneNumber, string supplierEmail, string itemName);
		string generateID();
		string generateDate();
		void printSupOrders();
};

#endif