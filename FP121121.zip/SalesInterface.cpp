#include <iostream>
#include <string>
#include <fstream>
#include <stdlib.h>
#include <vector>
#include <iomanip>
#include <cassert>
#include <ctime>
#pragma warning(disable : 4996)
using namespace std;

#include "SalesInterface.h"
#include "Categories.h"
#include "Beverages.h"
#include "Bread.h"
#include "Sales.h"
#include "Management.h"
#include "CurrentSale.h"



SalesInterface::SalesInterface() {

    bool quit = false;
    int menuSelect;
    // TODO: Switch 2 to 11 once all classes are added
    for (int i = 0; i < 2; i++) {
        openFile("Inventory/" + fileNames[i] + ".txt", items[i]);
    }


    while (!quit) {
        system("CLS");
        mainMenu();
        cin >> menuSelect;

        switch (menuSelect) {
        case 1:
            categoryMenu(items[0], "Beverages");
            break;
        case 2:
            categoryMenu(items[1], "Bread");
            break;
        case 12:
            createItem();
            break;
        case 13:
            checkOut();
            break;
        case 14:
            viewCart();
            break;
        case 15:

            break;
        case 16:
            managementMenu(*items);
            break;
        case 0:
        default:
            cout << "Thank you for using the POS/Inventory Software";
            quit = true;
            break;
        }

    }

}
SalesInterface::~SalesInterface() {

}

void SalesInterface::writeToSalesFile(string name, string phoneNumber, string itemName, int buyCount, double itemPrice) {

    double salesTotal = buyCount * itemPrice;
    time_t now = time(0);
    tm* ltm = localtime(&now);

    fstream file;
    string line;
    file.open("SalesFile.txt", ios::app);
    if (!file.is_open()) {
        cout << "File cannot be opened" << endl;
        assert(false);
    }

    file << ltm->tm_mon + 1 << "-" << ltm->tm_mday << "-" << 1900 + ltm->tm_year << "," << salesTotal << "," << name << "," << phoneNumber << "," << itemName << "," << buyCount << "," << itemPrice << "," << endl;

    file.close();

}

void SalesInterface::openFile(string fileName, vector<Categories*>& items) {
    ifstream file;
    string line;
    file.open(fileName, ios::in);
    if (!file.is_open()) {
        cout << "File cannot be opened" << endl;
        assert(false);
    }

    while (getline(file, line)) {

        // Splits the string using substrings and find
        string category = line.substr(0, ',');

        size_t startLocation = line.find(',') + 1;
        size_t size = line.find(',', startLocation + 1) - startLocation;
        string itemName = line.substr(startLocation, size);

        startLocation = line.find(',', startLocation) + 1;
        size = line.find(',', startLocation + 1) - startLocation;
        int itemID = stoi(line.substr(startLocation, size));

        startLocation = line.find(',', startLocation + 1) + 1;
        size = line.find(',', startLocation + 1) - startLocation;
        double itemPrice = stod(line.substr(startLocation, size));

        startLocation = line.find(',', startLocation + 1) + 1;
        size = line.find(',', startLocation + 1) - startLocation;
        int itemCount = stoi(line.substr(startLocation, size));

        if (category == "Beverages") {
            items.emplace_back(new Beverages(itemName, itemID, itemPrice, itemCount));
        }
        else if (category == "Bread") {
            //items.emplace_back(new Bread(itemName, itemID, itemPrice, itemCount));
        }
        else {
            items.emplace_back(new Beverages(itemName, itemID, itemPrice, itemCount));
        }

    }
    file.close();
}

void SalesInterface::orderMenu(vector<Categories*>& items, const string& categoryName) {

    cout << setw(16) << "Cat Name"
        << setw(14) << "Item Name"
        << setw(14) << "Item ID"
        << setw(14) << "Item Price"
        << setw(14) << "Item Count" << endl;

    int count = 1;
    for (auto& i : items) {
        cout << count << ".";
        i->print();
        count++;
    }
    cout << endl;
    cout << "Which item do you want?" << endl;
    // TODO: Add option to go back with 0 key
    int menuOption;
    cin >> menuOption;
    menuOption = menuOption - 1;
    if (menuOption >= items.size()) {
        cout << "Item not found..." << endl;
    }
    else {
        int buyCount;
        cout << "How many " << items[menuOption]->getMeasurement()
            << " of " << items[menuOption]->getItemName()
            << " would you like to buy?" << endl;
        cin >> buyCount;

        items[menuOption]->orderItem(buyCount);

        currentSale.emplace_back(items[menuOption]->getItemName(), categoryName, items[menuOption]->getItemPrice(), buyCount);
    }
}



void SalesInterface::categoryMenu(vector<Categories*> items, const string& categoryName) {

    system("CLS");

    bool quitMenu = false;
    int menuOption;

    cout << setw(14) << "Cat Name"
        << setw(14) << "Item Name"
        << setw(14) << "Item ID"
        << setw(14) << "Item Price"
        << setw(14) << "Item Count" << endl;

    for (auto& i : items) {
        i->print();
    }
    cout << endl;

    while (!quitMenu) {

        cout << "Select a task" << endl;
        cout << "1. Order " << categoryName << endl;
        cout << "0. Go Back" << endl;
        cout << endl;

        cin >> menuOption;

        switch (menuOption) {
        case 1:
            orderMenu(items, categoryName);
            break;
        case 2:
            break;
        case 0:
        default:
            quitMenu = true;
            break;
        }

    }

}

void SalesInterface::createItem() {

    system("CLS");
    string newItemName;
    string name;
    string phoneNumber;
    string itemCata = "Custom";
    double price;
    int amount;

    cout << "Enter the name of the item you which to purchase: ";
    cin >> newItemName;

    cout << endl << "Enter the price of the item: ";
    cin >> price;

    cout << endl << "How many " << newItemName << " would you like to purchase ? ";
    cin >> amount;

    cout << newItemName << "Has been added to your cart" << endl;

    currentSale.emplace_back(newItemName, itemCata, price, amount);

    system("pause");

}

void SalesInterface::mainMenu() {

    cout << "Welcome to the Store!" << endl;
    cout << "Select a Category (push 1, 2, 3, etc. to select)" << endl;
    cout << "1. Purchase Beverages" << endl;
    cout << "2. Purchase Bread & Bakery items" << endl;
    cout << "12. Create a new item." << endl;
    cout << "13. Check Out / Complete Sale" << endl;
    cout << "14. View Cart" << endl;
    cout << "15. Clear Cart" << endl;
    cout << "16. Management Menu" << endl;
    cout << "0. Quit" << endl;
    cout << endl;
}

void SalesInterface::managementMenu(vector<Categories*> items) {

    int menuSelect;
    Management* ptr;
    ptr = new Management();
    ptr->loadSupplierInfo();

    system("CLS");

    do {

        cout << "Select a management option (push 1, 2, 3, etc. to select)" << endl;
        cout << "1. View Current Inventory Status / Order Items" << endl;
        cout << "2. Print Total Sales by Date" << endl;
        cout << "3. Print Balance Sheet" << endl;
        cout << "4. Pay Debts to Suppliers" << endl;
        cout << "5. View current orders" << endl;
        cout << "0. Return to previous menu" << endl;
        cout << endl;

        cin >> menuSelect;

        switch (menuSelect) {
        case 1:
            system("CLS");
            ptr->restock(items);
            cout << endl;
            break;
        case 2:
            system("CLS");
            ptr->printTotalSalesByDate();
            break;
        case 3:
            system("CLS");
            ptr->printBalanceSheet(sales);
            break;
        case 4:
            system("CLS");
            ptr->paySuppliers();
            break;
        case 5:
            system("CLS");
            ptr->printSupOrders();
        case 0:
            break;
        }
    } while (menuSelect != 0);
}

void SalesInterface::checkOut() {

    system("CLS");

    string name = "";
    string phoneNumber = "";
    double subTotal = 0;
    int completePurchase = 0;
    double amountToPay = 0;

    cout << "Items in Cart" << endl;
    cout << "Item Name - Price - Amount to Purchase" << endl;
    int count = 1;
    for (int i = 0; i < currentSale.size(); i++) {
        cout << count << ". " << currentSale[i].getItemName() << " " << currentSale[i].getAmount() << " " << currentSale[i].getItemPrice() << endl;
        count++;
        subTotal = subTotal + (currentSale[i].getItemPrice() * currentSale[i].getAmount());
    }
    cout << endl << "Your order total is: $" << subTotal;

    cin.ignore();
    cout << "Please enter your name: ";
    getline(cin, name);

    cout << "Please enter your phone number: ";
    getline(cin, phoneNumber);

    cout << "Do you wish to complete your purchase? (1 = Yes, 2 = No) ";
    if (completePurchase == 1) {
        for (int i = 0; i < currentSale.size(); i++) {
            sales.emplace_back(name, phoneNumber, currentSale[i].getItemCat(), currentSale[i].getItemName(), currentSale[i].getAmount(), currentSale[i].getItemPrice());
            writeToSalesFile(name, phoneNumber, currentSale[i].getItemName(), currentSale[i].getAmount(), currentSale[i].getItemPrice());

        }
    }

    do {
        cout << endl << "Please enter the dollar amount to pay: $" << "you owe $" << subTotal << endl;
        cin >> amountToPay;
        subTotal = subTotal - amountToPay;
    } while (subTotal > 0);

    cout << "Thank you for your purchaase!" << endl;
    system("pause");

}

void SalesInterface::viewCart() {

    system("CLS");
    double subTotal = 0;
    int count = 1;

    cout << "Items in Cart" << endl;
    cout << "Item Name - Price - Amount to Purchase" << endl;

    for (int i = 0; i < currentSale.size(); i++) {
        cout << count << ". " << currentSale[i].getItemName() << " " << currentSale[i].getAmount() << " " << currentSale[i].getItemPrice() << endl;
        count++;
        subTotal = subTotal + (currentSale[i].getItemPrice() * currentSale[i].getAmount());
    }

    cout << endl << "Your order total is: $" << subTotal;

    system("Pause");
}
