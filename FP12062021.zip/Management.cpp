#include "Management.h"
#include "Categories.h"
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <cassert>
using namespace std;

Management::Management() {

}
Management::~Management() {

}
void Management::printItemsToReorder(vector<Categories*> items) {

    for (auto& i : items) {
        if (i->getReorderItem()) {
            cout << i->getItemName() << " " << i->getItemCount();
        }
    }

}
void Management::printInventory(vector<Categories*> items) {

    for (auto& i : items) {
        cout << i->getItemName() << " " << i->getItemCount() << endl;
    }

}
void Management::printTotalSalesByDate() {

    fstream file;
    string line;
    string currentDate = "";
    double runningTotal = 0;
    
    file.open("SalesFile.txt", ios::in);
    if (!file.is_open()) {
        cout << "File cannot be opened" << endl;
        //assert(false);
    }

    while (getline(file, line)) {

        // Splits the string using substrings and find
        string nextDate = line.substr(0, line.find(','));

        if (currentDate.compare("") == 0) {
            currentDate = nextDate;
        } 
        else if (currentDate.compare(nextDate) != 0) {
            cout << currentDate << " $" << runningTotal << endl;
            runningTotal = 0;
            currentDate = nextDate;
        }

        size_t startLocation = line.find(',') + 1;
        size_t size = line.find(',', startLocation + 1) - startLocation;
        runningTotal+= stod(line.substr(startLocation, size));

    }

    cout << currentDate << " $" << runningTotal;

    file.close();

}
void Management::paySuppliers() {

}
void Management::printBalanceSheet() {

}