#ifndef MANAGEMENT_H
#define MANAGEMENT_H
#include "Categories.h"
#include <string>
#include <iostream>
#include <iomanip>
#include <vector>

class Management
{

	public:
		Management();
		~Management();
		void printItemsToReorder(vector<Categories*> items);
		void printInventory(vector<Categories*> items);
		void printTotalSalesByDate();
		void paySuppliers();
		void printBalanceSheet();

};

#endif